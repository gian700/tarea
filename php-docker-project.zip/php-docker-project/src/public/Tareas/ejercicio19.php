<?php
    include "ejercicio16.php";
    function mcd(int $valor1, int $valor2){
        $divisoresDeValor1 = divisores($valor1);
        $divisoresDeValor2 = divisores($valor2);
        $arrayFinal = array_intersect($divisoresDeValor1, $divisoresDeValor2);
        return $arrayFinal[0];
    }

    echo mcd(100,500);
?>