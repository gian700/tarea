<?php
 /**
  * Da todos los numeros del 1 al 100
  * @return void
  */
 function numeros(){
    for ($i=1; $i < 101; $i++) { 
        echo $i . "\n";
    }
 }

 numeros();
?>