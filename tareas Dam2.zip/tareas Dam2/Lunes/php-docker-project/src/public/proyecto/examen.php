<?php
    echo "hola, examen";
?>