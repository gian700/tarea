<html>
  <head> <title>Hello, world</title> </head>
  <body>
    <?php echo "Hello, world!"; ?>
  </body>
</html>